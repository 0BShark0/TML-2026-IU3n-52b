"""Веб-приложение для демонстрации моделей машинного обучения (вариант 2: несколько моделей).

Запуск:  streamlit run app.py
"""
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.datasets import load_breast_cancer, load_wine
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, RocCurveDisplay, accuracy_score, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

st.set_page_config(page_title="Демонстрация моделей ML", page_icon="📊", layout="wide")

DATASETS = {
    "Breast Cancer (2 класса)": load_breast_cancer,
    "Wine (3 класса)": load_wine,
}
MODEL_NAMES = ["Логистическая регрессия", "Метод ближайших соседей", "SVM",
               "Дерево решений", "Случайный лес", "Градиентный бустинг"]


@st.cache_data
def load_dataset(name: str):
    bunch = DATASETS[name]()
    X = pd.DataFrame(bunch.data, columns=bunch.feature_names)
    y = pd.Series(bunch.target, name="target")
    return X, y, list(bunch.target_names)


def hyperparameter_controls(model_name: str) -> dict:
    """Элементы управления гиперпараметрами выбранной модели в боковой панели."""
    key = model_name
    if model_name == "Логистическая регрессия":
        return {"C": st.slider("C (обратная сила регуляризации)", 0.01, 10.0, 1.0, 0.01, key=f"{key}_C")}
    if model_name == "Метод ближайших соседей":
        return {"n_neighbors": st.slider("Число соседей K", 1, 50, 5, key=f"{key}_k"),
                "weights": st.selectbox("Веса соседей", ["uniform", "distance"], key=f"{key}_w")}
    if model_name == "SVM":
        return {"C": st.slider("C", 0.01, 20.0, 1.0, 0.01, key=f"{key}_C"),
                "kernel": st.selectbox("Ядро", ["rbf", "linear", "poly"], key=f"{key}_kernel")}
    if model_name == "Дерево решений":
        return {"max_depth": st.slider("Максимальная глубина", 1, 20, 4, key=f"{key}_depth"),
                "min_samples_leaf": st.slider("Мин. объектов в листе", 1, 30, 1, key=f"{key}_leaf")}
    if model_name == "Случайный лес":
        return {"n_estimators": st.slider("Число деревьев", 10, 500, 100, 10, key=f"{key}_n"),
                "max_depth": st.slider("Максимальная глубина", 1, 20, 8, key=f"{key}_depth")}
    if model_name == "Градиентный бустинг":
        return {"n_estimators": st.slider("Число деревьев", 10, 500, 100, 10, key=f"{key}_n"),
                "learning_rate": st.slider("Скорость обучения", 0.01, 1.0, 0.1, 0.01, key=f"{key}_lr"),
                "max_depth": st.slider("Глубина деревьев", 1, 8, 3, key=f"{key}_depth")}
    raise ValueError(model_name)


def build_model(model_name: str, params: dict, random_state: int):
    """Создание модели; метрическим и линейным моделям нужен StandardScaler."""
    if model_name == "Логистическая регрессия":
        return Pipeline([("scaler", StandardScaler()), ("model", LogisticRegression(max_iter=5000, **params))])
    if model_name == "Метод ближайших соседей":
        return Pipeline([("scaler", StandardScaler()), ("model", KNeighborsClassifier(**params))])
    if model_name == "SVM":
        return Pipeline([("scaler", StandardScaler()),
                         ("model", SVC(probability=True, random_state=random_state, **params))])
    if model_name == "Дерево решений":
        return DecisionTreeClassifier(random_state=random_state, **params)
    if model_name == "Случайный лес":
        return RandomForestClassifier(random_state=random_state, n_jobs=-1, **params)
    if model_name == "Градиентный бустинг":
        return GradientBoostingClassifier(random_state=random_state, **params)
    raise ValueError(model_name)


def evaluate(model, X_test, y_test, n_classes: int) -> dict:
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)
    average = "binary" if n_classes == 2 else "macro"
    roc_auc = (roc_auc_score(y_test, proba[:, 1]) if n_classes == 2
               else roc_auc_score(y_test, proba, multi_class="ovr", average="macro"))
    return {"Accuracy": accuracy_score(y_test, pred),
            "Precision": precision_score(y_test, pred, average=average, zero_division=0),
            "Recall": recall_score(y_test, pred, average=average),
            "F1": f1_score(y_test, pred, average=average),
            "ROC AUC": roc_auc}


def feature_importance(model):
    estimator = model.named_steps["model"] if isinstance(model, Pipeline) else model
    if hasattr(estimator, "feature_importances_"):
        return estimator.feature_importances_
    if hasattr(estimator, "coef_"):
        return np.abs(estimator.coef_).mean(axis=0)
    return None


# ---------------------------------------------------------------- боковая панель: параметры
st.sidebar.header("1. Данные")
dataset_name = st.sidebar.selectbox("Набор данных", list(DATASETS))
test_size = st.sidebar.slider("Доля тестовой выборки", 0.1, 0.5, 0.25, 0.05)
random_state = st.sidebar.number_input("random_state", 0, 10_000, 42)
use_cv = st.sidebar.checkbox("Дополнительно оценить кросс-валидацией (5 фолдов)", value=False)

st.sidebar.header("2. Модели")
selected = st.sidebar.multiselect("Выберите модели для обучения", MODEL_NAMES,
                                  default=["Логистическая регрессия", "Случайный лес"])

st.sidebar.header("3. Гиперпараметры")
all_params = {}
for name in selected:
    with st.sidebar.expander(name, expanded=False):
        all_params[name] = hyperparameter_controls(name)

train_clicked = st.sidebar.button("Обучить модели", type="primary", disabled=not selected)

# ---------------------------------------------------------------- основная часть
st.title("Демонстрация моделей машинного обучения")
st.caption("Выберите набор данных, модели и их гиперпараметры в панели слева и нажмите «Обучить модели».")

X, y, class_names = load_dataset(dataset_name)
n_classes = len(class_names)

with st.expander("Описание набора данных", expanded=not st.session_state.get("results")):
    c1, c2, c3 = st.columns(3)
    c1.metric("Объектов", X.shape[0])
    c2.metric("Признаков", X.shape[1])
    c3.metric("Классов", n_classes)
    balance = y.value_counts().sort_index()
    balance.index = [class_names[i] for i in balance.index]
    st.bar_chart(balance)
    st.dataframe(X.head(), use_container_width=True)

# Конфигурация, с которой были получены текущие результаты: при изменении параметров результаты скрываются
config = {"dataset": dataset_name, "test_size": test_size, "random_state": int(random_state),
          "use_cv": use_cv, "models": {n: all_params[n] for n in selected}}

if train_clicked:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size,
                                                        random_state=int(random_state), stratify=y)
    results = {}
    progress = st.progress(0.0, text="Обучение…")
    for i, name in enumerate(selected):
        model = build_model(name, all_params[name], int(random_state))
        start = time.perf_counter()
        model.fit(X_train, y_train)
        elapsed = time.perf_counter() - start
        metrics = evaluate(model, X_test, y_test, n_classes)
        metrics["Время обучения, с"] = elapsed
        if use_cv:
            metrics["F1 (CV, среднее)"] = cross_val_score(
                build_model(name, all_params[name], int(random_state)), X_train, y_train, cv=5,
                scoring="f1" if n_classes == 2 else "f1_macro").mean()
        results[name] = {"model": model, "metrics": metrics}
        progress.progress((i + 1) / len(selected), text=f"Обучено: {name}")
    progress.empty()
    st.session_state["results"] = results
    st.session_state["config"] = config
    st.session_state["split"] = (X_test, y_test)

results = st.session_state.get("results")
if results and st.session_state.get("config") != config:
    st.info("Параметры изменились — нажмите «Обучить модели», чтобы обновить результаты.")
elif results:
    X_test, y_test = st.session_state["split"]
    st.header("Результаты обучения")
    table = pd.DataFrame({name: r["metrics"] for name, r in results.items()}).T
    st.caption("Precision, Recall и F1: для двух классов — по классу с меткой 1 "
               f"(«{class_names[1]}»), для трёх классов — среднее по классам (macro). "
               "Лучшее значение каждой метрики выделено зелёным.")
    best = table["F1"].idxmax()
    st.success(f"Лучшая модель по F1 на тестовой выборке: **{best}** (F1 = {table.loc[best, 'F1']:.3f})")
    st.dataframe(table.style.format("{:.4f}").highlight_max(
        subset=[c for c in table.columns if not c.startswith("Время")], color="#c8e6c9"), use_container_width=True)

    tab_metrics, tab_cm, tab_roc, tab_imp = st.tabs(
        ["Сравнение метрик", "Матрицы ошибок", "ROC-кривые", "Важность признаков"])

    with tab_metrics:
        metric_cols = ["Accuracy", "Precision", "Recall", "F1", "ROC AUC"]
        fig, ax = plt.subplots(figsize=(11, 4.5))
        table[metric_cols].plot.bar(ax=ax, rot=15)
        ax.set_ylim(max(0.0, table[metric_cols].values.min() - 0.05), 1.0)
        ax.set_title("Метрики на тестовой выборке")
        ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0))
        fig.tight_layout()
        st.pyplot(fig)

    with tab_cm:
        cols = st.columns(min(3, len(results)))
        for i, (name, r) in enumerate(results.items()):
            fig, ax = plt.subplots(figsize=(4, 3.6))
            ConfusionMatrixDisplay.from_estimator(r["model"], X_test, y_test, display_labels=class_names,
                                                  cmap="Blues", ax=ax, colorbar=False)
            ax.set_title(name, fontsize=10)
            ax.grid(False)
            cols[i % len(cols)].pyplot(fig)

    with tab_roc:
        if n_classes == 2:
            fig, ax = plt.subplots(figsize=(6, 5))
            for name, r in results.items():
                RocCurveDisplay.from_estimator(r["model"], X_test, y_test, name=name, ax=ax)
            ax.plot([0, 1], [0, 1], "k--", lw=1)
            st.pyplot(fig)
        else:
            st.write("Для многоклассовой задачи показаны ROC-кривые «один против остальных» для каждой модели.")
            cols = st.columns(min(3, len(results)))
            for i, (name, r) in enumerate(results.items()):
                proba = r["model"].predict_proba(X_test)
                fig, ax = plt.subplots(figsize=(4.5, 4))
                for cls in range(n_classes):
                    RocCurveDisplay.from_predictions(y_test == cls, proba[:, cls], name=class_names[cls], ax=ax)
                ax.plot([0, 1], [0, 1], "k--", lw=1)
                ax.set_title(name, fontsize=10)
                cols[i % len(cols)].pyplot(fig)

    with tab_imp:
        shown = False
        for name, r in results.items():
            imp = feature_importance(r["model"])
            if imp is None:
                continue
            shown = True
            series = pd.Series(imp, index=X.columns).sort_values().tail(10)
            fig, ax = plt.subplots(figsize=(7, 3.8))
            series.plot.barh(ax=ax, color="darkorange")
            ax.set_title(f"{name}: 10 наиболее важных признаков")
            st.pyplot(fig)
        if not shown:
            st.write("У выбранных моделей (KNN, SVM) нет встроенной оценки важности признаков.")
else:
    st.info("Модели ещё не обучены.")
