# Технологии машинного обучения — лабораторные работы (весна 2025)

Курс: https://github.com/ugapanyuk/courses_current/wiki/COURSE_TMO_SPRING_2025

| № | Тема | Датасет | Ноутбук |
| --- | --- | --- | --- |
| 1 | Разведочный анализ данных. Исследование и визуализация данных | Wine (sklearn) | [lab1_eda_visualization.ipynb](notebooks/lab1_eda_visualization.ipynb) |
| 2 | Обработка пропусков, кодирование категориальных признаков, масштабирование | Titanic | [lab2_missing_encoding_scaling.ipynb](notebooks/lab2_missing_encoding_scaling.ipynb) |
| 3 | Обучающая и тестовая выборки, кросс-валидация, подбор гиперпараметров (KNN) | Breast Cancer (sklearn) | [lab3_knn_cv_hyperparams.ipynb](notebooks/lab3_knn_cv_hyperparams.ipynb) |
| 4 | Линейные модели, SVM и деревья решений | Diabetes (sklearn) | [lab4_linear_svm_trees.ipynb](notebooks/lab4_linear_svm_trees.ipynb) |
| 5 | Ансамбли моделей машинного обучения. Часть 1 | Titanic | [lab5_ensembles_1.ipynb](notebooks/lab5_ensembles_1.ipynb) |
| 6 | Ансамбли моделей машинного обучения. Часть 2 (стекинг, MLP, МГУА) | Diabetes (sklearn) | [lab6_ensembles_2.ipynb](notebooks/lab6_ensembles_2.ipynb) |

**Дополнительные работы** (каждая даёт +1 балл на экзамене):

| № | Тема | Данные | Отчёт |
| --- | --- | --- | --- |
| Д1 | Анализ и прогнозирование временного ряда (SARIMA, символьная регрессия, МГУА) | Airline Passengers | [extra1_time_series.ipynb](notebooks/extra1_time_series.ipynb) |
| Д2 | Веб-приложение для демонстрации моделей ML (Streamlit, вариант 2) | Breast Cancer, Wine | [extra2_web_app.ipynb](notebooks/extra2_web_app.ipynb), код — [web_app/app.py](web_app/app.py) |
| Д3 | Методы обучения без учителя (PCA, t-SNE, кластеризация) | Wine | [extra3_clustering.ipynb](notebooks/extra3_clustering.ipynb) |

Каждый ноутбук — отчёт: титульный лист, задание, код с результатами выполнения (графики, таблицы) и выводы.
Ноутбуки уже выполнены; копии в HTML лежат в папке `html/` (открываются в браузере, удобно печатать в PDF).

**Перед сдачей** заполните на титульном листе каждого ноутбука номер группы (`ИУ5-__Б`) и ФИО.

## Запуск

```sh
python -m venv venv
venv\Scripts\activate            # Windows; в Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
jupyter notebook notebooks
```

Ноутбуки ЛР2, ЛР5 и Д1 читают файлы из `data/` по относительному пути, поэтому запускайте их из папки `notebooks`.

Веб-приложение (Д2) запускается отдельно и требует NumPy 2 (из-за `pyarrow` в Streamlit), поэтому для него
нужно своё окружение:

```sh
cd web_app
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Для ЛР6 и Д1 нужен Python 3.10/3.11 и `numpy<2` (см. раздел 6 ноутбука — замечания для отзыва о библиотеке `gmdh`).
